import { useState } from 'react';

export default function App() {
  const [input, setInput] = useState('');
  const [messages, setMessages] = useState([
    { type: 'bot', text: "Hi, I'm EchoJay 👋 Ask me anything about how I work." }
  ]);

  const sendMessage = async () => {
    if (!input.trim()) return;
    const userMsg = { type: 'user', text: input };
    setMessages(prev => [...prev, userMsg]);
    setInput('');

    const response = await fetch('https://api.openai.com/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': 'Bearer YOUR_API_KEY_HERE'
      },
      body: JSON.stringify({
        model: 'gpt-4',
        messages: [{ role: 'system', content: 'You are Jay, a calm and confident PM.' },
                   { role: 'user', content: input }]
      })
    });

    const data = await response.json();
    const reply = data?.choices?.[0]?.message?.content;
    if (reply) {
      setMessages(prev => [...prev, { type: 'bot', text: reply }]);
    }
  };

  return (
    <div className="p-4 max-w-xl mx-auto">
      <h1 className="text-2xl font-bold mb-4">EchoMind: Jay Clone MVP</h1>
      <div className="border p-4 rounded h-96 overflow-y-auto bg-gray-50 mb-4">
        {messages.map((msg, i) => (
          <div key={i} className={`my-2 ${msg.type === 'user' ? 'text-right' : 'text-left'}`}>
            <span className={`inline-block p-2 rounded ${msg.type === 'user' ? 'bg-blue-200' : 'bg-gray-200'}`}>
              {msg.text}
            </span>
          </div>
        ))}
      </div>
      <div className="flex gap-2">
        <input
          className="border p-2 rounded w-full"
          value={input}
          onChange={e => setInput(e.target.value)}
          onKeyDown={e => e.key === 'Enter' && sendMessage()}
        />
        <button onClick={sendMessage} className="bg-blue-600 text-white px-4 py-2 rounded">Send</button>
      </div>
    </div>
  );
}